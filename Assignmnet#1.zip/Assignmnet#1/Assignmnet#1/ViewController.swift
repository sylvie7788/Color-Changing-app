//
//  ViewController.swift
//  Assignmnet#1
//
//  Created by sylvie chen on 4/13/20.
//  Copyright © 2020 sylvie chen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var cover: UIImageView!
    
    @IBOutlet weak var red: UISlider!
    @IBOutlet weak var rvalue: UILabel!
    
    @IBOutlet weak var green: UISlider!
    @IBOutlet weak var gvalue: UILabel!
    
    @IBOutlet weak var blue: UISlider!
    @IBOutlet weak var bvalue: UILabel!
    
    @IBOutlet weak var opague: UISlider!
    
    
    @IBAction func slider1(_ sender: UISlider) {

            cover.backgroundColor = UIColor(red: CGFloat(red.value)/255, green: CGFloat(green.value)/255, blue: CGFloat(blue.value)/255, alpha: CGFloat(opague.value)  );
        
        }
    
    
    @IBAction func slider2(_ sender: UISlider) {
         cover.backgroundColor = UIColor(red: CGFloat(red.value)/255, green: CGFloat(green.value)/255, blue: CGFloat(blue.value)/255, alpha: CGFloat(opague.value)  );
         
    }
    
    
    @IBAction func slider3(_ sender: UISlider) {
        cover.backgroundColor = UIColor(red: CGFloat(red.value)/255, green: CGFloat(green.value)/255, blue: CGFloat(blue.value)/255, alpha: CGFloat(opague.value)  );

    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        red.setValue(Float.random(in:0...255), animated: true);
        green.setValue(Float.random(in:0...255), animated: true);
        blue.setValue(Float.random(in:0...255), animated: true);
        
        cover.backgroundColor = UIColor.black;
//        red.value =  Float.random(in:0...255);
//        green.value = Float.random(in:0...255);
//        blue.value = Float.random(in:0...255);

        
         
    }
    
       


}

